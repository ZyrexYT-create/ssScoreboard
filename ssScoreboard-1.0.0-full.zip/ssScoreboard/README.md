# ssScoreboard

**Minecraft Scoreboard + TAB Plugin** with world-specific displays, animations, bossbars, and full configuration fallback.

**Version:** 1.0.0  
**Author:** ssDevelopment  
**Target:** PaperMC 1.21 – 1.21.11  
**Java:** 21  

---

## Overview

ssScoreboard combines sidebar scoreboards, TAB header/footer, player-list name formatting, scoreboard teams, player-list & below-name objectives, and bossbars into a single configurable plugin.

Key features:

- **Per-world configuration** with automatic fallback
- **Recursive config merging** (override only what you need)
- RGB hex colors, legacy colors, MiniMessage, and custom shadow tags
- Centralized animations (`%animation:Name%`)
- PlaceholderAPI, Vault, and LuckPerms support (all optional)
- Multiverse-Core compatible (uses actual Bukkit world names)
- Efficient single update task (no per-player animation spam)
- Commands, permissions, and hot-reload

---

## Compatibility Report

| Category | Versions |
|----------|----------|
| **Compiled against** | Paper API 1.21.1-R0.1-SNAPSHOT |
| **Expected to work** | Paper 1.21, 1.21.1, 1.21.3, 1.21.4, 1.21.5, 1.21.8, 1.21.10, 1.21.11 (API-compatible) |
| **Actually tested on running server** | **None** – no Paper server was available in the build environment. Unit tests only. |

---

## Installation

1. Build the plugin (see Build Instructions) or download the JAR.
2. Place `ssScoreboard-1.0.0.jar` into your server’s `plugins/` folder.
3. Start (or restart) the server.
4. Edit the generated files in `plugins/ssScoreboard/`.
5. Run `/ssscoreboard reload`.

**Optional soft-dependencies:**

- PlaceholderAPI (+ expansions for the placeholders you use)
- Vault (+ an economy plugin)
- LuckPerms
- Multiverse-Core

The plugin works without any of them.

---

## World Configuration System

### File layout

```
plugins/ssScoreboard/
├── config.yml          # Global defaults
├── animations.yml
├── messages.yml
└── worlds/
    ├── world.yml           # Default world (fallback for everything)
    ├── world_nether.yml    # Optional overrides
    ├── world_the_end.yml
    └── <any-world>.yml     # Multiverse / custom worlds
```

### Fallback priority (mandatory)

1. Exact world file (`worlds/<worldname>.yml`)
2. Default world file (`worlds/world.yml`)
3. Global `config.yml`

**Missing a world file never disables the scoreboard or TAB.**  
If only `world.yml` exists, every world (Nether, End, Multiverse, etc.) inherits from it.

### Independent section inheritance

A world file may override only the sections/keys it cares about. All other sections are inherited recursively.

Example – `world_nether.yml` containing only:

```yaml
scoreboard:
  title: "&c&lNETHER"
```

Result in the Nether:

- Custom title
- All other scoreboard settings from `world.yml`
- Full TAB header/footer from `world.yml`
- Teams, objectives, bossbars from `world.yml`

### Missing vs explicitly disabled

```yaml
# Missing key → inherit
header-footer:
  # enabled not present

# Explicitly disabled
scoreboard:
  enabled: false
```

---

## Configuration Examples

See the generated `config.yml`, `worlds/world.yml`, `worlds/world_nether.yml`, and `worlds/world_the_end.yml` for complete schemas.

### Scoreboard

```yaml
scoreboard:
  enabled: true
  update-interval: 20
  title: "<shadow:0000FF>&#FF0000&lYour Server"
  lines:
    - ""
    - "<shadow:0000FF>&#FFBB00☄ &#FF0029%player%"
    - "..."
```

### TAB Header / Footer

```yaml
header-footer:
  enabled: true
  header:
    - "&#00B8FF&lYour Server"
  footer:
    - "%animation:Labels%"
```

### Animations

```yaml
# animations.yml
Labels:
  change-interval: 6400
  texts:
    - "&#e30ea4&nSTORE ..."
    - "..."
```

Use with `%animation:Labels%`.

### Bossbars

```yaml
bossbar:
  enabled: true
  bars:
    ServerInfo:
      style: PROGRESS
      color: YELLOW
      progress: "100"
      text: "&aPlaying on play.yourserver.fun"
```

---

## Formatting

| Syntax | Example | Notes |
|--------|---------|-------|
| Legacy | `&cRed &lBold` | Fully supported |
| Hex | `&#00B8FFText` | Converted to Adventure |
| MiniMessage | `<red>Text</red>` | Supported |
| Shadow (custom) | `<shadow:0000FF>Text` | Approximated with colored bold text (client text-shadow is limited) |

---

## Commands

| Command | Permission | Description |
|---------|------------|-------------|
| `/ssscoreboard` | `ssscoreboard.admin` | Show usage |
| `/ssscoreboard reload` | `ssscoreboard.reload` | Reload all configs |
| `/ssscoreboard toggle` | `ssscoreboard.toggle` | Toggle own scoreboard |
| `/ssscoreboard toggle <player>` | `ssscoreboard.toggle.others` | Toggle another player |
| `/ssscoreboard debug` | `ssscoreboard.debug` | Toggle debug logging |
| `/ssscoreboard info` | — | Plugin info |
| `/ssscoreboard version` | — | Version |
| `/bossbar` | `ssscoreboard.bossbar.toggle` | Toggle personal bossbars |

Aliases: `/sss`, `/sssb`

---

## Permissions

- `ssscoreboard.admin` (default: op) – parent of most admin nodes
- `ssscoreboard.reload` (op)
- `ssscoreboard.toggle` (true)
- `ssscoreboard.toggle.others` (op)
- `ssscoreboard.debug` (op)
- `ssscoreboard.bypass` (false)
- `ssscoreboard.bossbar` (true)
- `ssscoreboard.bossbar.toggle` (true)

---

## Placeholders

**Built-in:**

- `%player%`, `%world%`, `%ping%`, `%server_online%`, `%server_tps%`, `%uuid%`

**Animation:**

- `%animation:Labels%`, `%animation:InfoText%`, `%animation:InfoLink%`, `%animation:ProgressBar%`

**Via PlaceholderAPI (when present):**

- `%luckperms_prefix%`, `%vault_eco_balance_formatted%`, `%statistics_time_played%`, etc.

Missing expansions are left unresolved or replaced with empty/default values safely.

---

## API Limitations (honest)

- **Below-name objective** is numeric only. The plugin can display a number (e.g. ping or money as integer). Fancy multi-part text in the below-name slot is not supported by the Minecraft client via a single objective.
- **Player-list objective** (the number next to names in TAB) is also numeric.
- **Shadow tags** are approximated; true client-side text shadow is not universally controllable via the public API.
- **Scoreboard lines** are limited to 15 visible lines (Minecraft limit).
- Team names are kept short for compatibility.

---

## Build Instructions

```bash
cd ssScoreboard
mvn clean package
```

The JAR will be located at:

```
target/ssScoreboard-1.0.0.jar
```

---

## Testing Status

### Unit tests

- World configuration fallback & recursive merge
- Missing vs explicit disable
- Animation frame advancement
- Condition expression parsing
- Basic formatting helpers

Run with:

```bash
mvn test
```

### Integration tests

**Not performed.** No Paper server was available in the development environment.  
All claims of runtime behavior on a live server are based on correct use of the public Paper/Adventure API.

---

## Feature Implementation Checklist

- [x] Per-world configuration files
- [x] Fallback to `world.yml` then global config
- [x] Recursive section merging
- [x] Missing vs explicitly disabled distinction
- [x] Multiverse / custom world support via Bukkit world names
- [x] Sidebar scoreboard with title + lines
- [x] TAB header & footer
- [x] TAB player-name formatting
- [x] Scoreboard teams + sorting types
- [x] Player-list objective (optional)
- [x] Below-name objective (numeric)
- [x] Bossbars with progress / color / style
- [x] Centralized animations
- [x] RGB, legacy, MiniMessage, shadow formatting
- [x] PlaceholderAPI soft-depend
- [x] Commands + permissions + tab completion
- [x] Hot reload of all configs
- [x] Player join / quit / world-change / respawn handling
- [x] Unit tests for core logic
- [x] Complete Maven project

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Scoreboard missing in Nether | Check that `scoreboard.enabled` is not `false` in any applicable config. Missing file = inherit. |
| TAB not updating | Ensure `header-footer.enabled` is true (or missing). Reload after changes. |
| Placeholders show as `%...%` | Install PlaceholderAPI + required expansions, or use only built-in ones. |
| Duplicate objectives / flicker | Another scoreboard plugin is fighting for the sidebar. Disable the other plugin’s sidebar. |
| Config not applying | Run `/ssscoreboard reload`. Check console for YAML errors. |

---

## License

All rights reserved – ssDevelopment 2026.
