package dev.sscoreboard;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Centralized animation system.
 * Animations are advanced by a single shared scheduler (UpdateTask),
 * not per-player tasks.
 */
public class AnimationManager {

    private final SSScoreboard plugin;
    private final Map<String, Animation> animations = new ConcurrentHashMap<>();
    private long currentTick = 0;

    public AnimationManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void load() {
        animations.clear();
        File file = new File(plugin.getDataFolder(), "animations.yml");
        if (!file.exists()) {
            plugin.saveResource("animations.yml", false);
        }
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        for (String key : cfg.getKeys(false)) {
            ConfigurationSection section = cfg.getConfigurationSection(key);
            if (section == null) continue;

            int interval = section.getInt("change-interval", 20);
            List<String> texts = section.getStringList("texts");
            if (texts.isEmpty()) continue;

            animations.put(key.toLowerCase(), new Animation(key, interval, texts));
        }

        plugin.getLogger().info("Loaded " + animations.size() + " animations.");
    }

    /**
     * Called every tick by UpdateTask to advance animation frames.
     */
    public void tick() {
        currentTick++;
        for (Animation anim : animations.values()) {
            anim.advanceIfNeeded(currentTick);
        }
    }

    /**
     * Returns the current frame text for an animation name, or the placeholder itself if missing.
     */
    public String getCurrentFrame(String name) {
        if (name == null) return "";
        Animation anim = animations.get(name.toLowerCase());
        if (anim == null) {
            return "%animation:" + name + "%";
        }
        return anim.getCurrentText();
    }

    public boolean hasAnimation(String name) {
        return name != null && animations.containsKey(name.toLowerCase());
    }

    public Map<String, Animation> getAnimations() {
        return animations;
    }

    public static class Animation {
        private final String name;
        private final int interval;
        private final List<String> texts;
        private int currentIndex = 0;
        private long lastChangeTick = 0;

        public Animation(String name, int interval, List<String> texts) {
            this.name = name;
            this.interval = Math.max(1, interval);
            this.texts = new ArrayList<>(texts);
        }

        public void advanceIfNeeded(long currentTick) {
            if (currentTick - lastChangeTick >= interval) {
                currentIndex = (currentIndex + 1) % texts.size();
                lastChangeTick = currentTick;
            }
        }

        public String getCurrentText() {
            if (texts.isEmpty()) return "";
            return texts.get(currentIndex);
        }

        public String getName() {
            return name;
        }

        public int getInterval() {
            return interval;
        }

        public List<String> getTexts() {
            return texts;
        }
    }
}
