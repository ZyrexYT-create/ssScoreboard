package dev.sscoreboard;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages bossbars with support for multiple named bars, progress, colors, styles,
 * and per-player toggle.
 */
public class BossBarManager {

    private final SSScoreboard plugin;
    private final Map<UUID, Map<String, BossBar>> playerBars = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> toggledOff = new ConcurrentHashMap<>();

    public BossBarManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void updatePlayer(Player player) {
        if (isToggledOff(player)) {
            hideAll(player);
            return;
        }

        String world = player.getWorld().getName();
        if (!plugin.getWorldConfigResolver().isBossBarEnabled(world)) {
            hideAll(player);
            return;
        }

        var cfg = plugin.getWorldConfigResolver().resolve(world);
        ConfigurationSection barsSection = cfg.getConfigurationSection("bossbar.bars");
        if (barsSection == null) {
            // Fall back to global
            barsSection = plugin.getConfigManager().getConfig().getConfigurationSection("bossbar.bars");
        }
        if (barsSection == null) {
            hideAll(player);
            return;
        }

        Map<String, BossBar> current = playerBars.computeIfAbsent(player.getUniqueId(),
                k -> new ConcurrentHashMap<>());

        Set<String> activeNames = new HashSet<>();

        for (String barName : barsSection.getKeys(false)) {
            ConfigurationSection barCfg = barsSection.getConfigurationSection(barName);
            if (barCfg == null) continue;

            activeNames.add(barName);

            String textRaw = barCfg.getString("text", "");
            String progressStr = barCfg.getString("progress", "100");
            String colorName = barCfg.getString("color", "YELLOW");
            String styleName = barCfg.getString("style", "PROGRESS");

            String textResolved = plugin.getPlaceholderManager().resolve(player, textRaw);
            Component text = plugin.getTextFormatter().format(textResolved);

            float progress = parseProgress(player, progressStr);
            BossBar.Color color = parseColor(colorName);
            BossBar.Overlay style = parseStyle(styleName);

            BossBar bar = current.get(barName);
            if (bar == null) {
                bar = BossBar.bossBar(text, progress, color, style);
                current.put(barName, bar);
                player.showBossBar(bar);
            } else {
                bar.name(text);
                bar.progress(progress);
                bar.color(color);
                bar.overlay(style);
            }
        }

        // Remove bars no longer configured
        Iterator<Map.Entry<String, BossBar>> it = current.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, BossBar> entry = it.next();
            if (!activeNames.contains(entry.getKey())) {
                player.hideBossBar(entry.getValue());
                it.remove();
            }
        }
    }

    private float parseProgress(Player player, String progressStr) {
        // Support placeholder or animation that resolves to a number 0-100
        String resolved = plugin.getPlaceholderManager().resolve(player, progressStr);
        try {
            double val = Double.parseDouble(resolved.replace("%", "").trim());
            return (float) Math.max(0.0, Math.min(1.0, val / 100.0));
        } catch (NumberFormatException e) {
            return 1.0f;
        }
    }

    private BossBar.Color parseColor(String name) {
        try {
            return BossBar.Color.valueOf(name.toUpperCase());
        } catch (Exception e) {
            return BossBar.Color.YELLOW;
        }
    }

    private BossBar.Overlay parseStyle(String name) {
        try {
            // Paper uses Overlay; map common names
            return switch (name.toUpperCase()) {
                case "NOTCHED_6", "NOTCHED6" -> BossBar.Overlay.NOTCHED_6;
                case "NOTCHED_10", "NOTCHED10" -> BossBar.Overlay.NOTCHED_10;
                case "NOTCHED_12", "NOTCHED12" -> BossBar.Overlay.NOTCHED_12;
                case "NOTCHED_20", "NOTCHED20" -> BossBar.Overlay.NOTCHED_20;
                default -> BossBar.Overlay.PROGRESS;
            };
        } catch (Exception e) {
            return BossBar.Overlay.PROGRESS;
        }
    }

    public void toggle(Player player) {
        boolean currentlyOff = isToggledOff(player);
        if (currentlyOff) {
            toggledOff.remove(player.getUniqueId());
            updatePlayer(player);
        } else {
            toggledOff.put(player.getUniqueId(), true);
            hideAll(player);
        }
    }

    public boolean isToggledOff(Player player) {
        return Boolean.TRUE.equals(toggledOff.get(player.getUniqueId()));
    }

    private void hideAll(Player player) {
        Map<String, BossBar> bars = playerBars.remove(player.getUniqueId());
        if (bars != null) {
            for (BossBar bar : bars.values()) {
                player.hideBossBar(bar);
            }
        }
    }

    public void cleanupPlayer(Player player) {
        hideAll(player);
        toggledOff.remove(player.getUniqueId());
    }

    public void cleanupAll() {
        for (UUID uuid : new HashSet<>(playerBars.keySet())) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) {
                hideAll(p);
            }
        }
        playerBars.clear();
        toggledOff.clear();
    }
}
