package dev.sscoreboard;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CommandManager implements CommandExecutor, TabCompleter {

    private final SSScoreboard plugin;

    public CommandManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void register() {
        var cmd = plugin.getCommand("ssscoreboard");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        var bossbarCmd = plugin.getCommand("bossbar");
        if (bossbarCmd != null) {
            bossbarCmd.setExecutor((sender, command, label, args) -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(plugin.getTextFormatter().format(
                            plugin.getConfigManager().getMessage("player-only")));
                    return true;
                }
                if (!player.hasPermission("ssscoreboard.bossbar.toggle")) {
                    player.sendMessage(plugin.getTextFormatter().format(
                            plugin.getConfigManager().getMessage("no-permission")));
                    return true;
                }
                plugin.getBossBarManager().toggle(player);
                boolean off = plugin.getBossBarManager().isToggledOff(player);
                String msg = off ? "bossbar-toggled-off" : "bossbar-toggled-on";
                player.sendMessage(plugin.getTextFormatter().format(
                        plugin.getConfigManager().getMessage(msg)));
                return true;
            });
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "reload" -> handleReload(sender);
            case "toggle" -> handleToggle(sender, args);
            case "debug" -> handleDebug(sender);
            case "info" -> handleInfo(sender);
            case "version" -> handleVersion(sender);
            default -> {
                sender.sendMessage(plugin.getTextFormatter().format(
                        plugin.getConfigManager().getMessage("unknown-subcommand")));
                sendUsage(sender);
            }
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("ssscoreboard.reload")) {
            sender.sendMessage(plugin.getTextFormatter().format(
                    plugin.getConfigManager().getMessage("no-permission")));
            return;
        }
        boolean ok = plugin.reload();
        String msg = ok ? "reload-success" : "reload-failed";
        sender.sendMessage(plugin.getTextFormatter().format(
                plugin.getConfigManager().getMessage(msg)));
    }

    private void handleToggle(CommandSender sender, String[] args) {
        if (args.length >= 2) {
            // Toggle other
            if (!sender.hasPermission("ssscoreboard.toggle.others")) {
                sender.sendMessage(plugin.getTextFormatter().format(
                        plugin.getConfigManager().getMessage("no-permission")));
                return;
            }
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(plugin.getTextFormatter().format(
                        plugin.getConfigManager().getMessage("toggle-player-not-found",
                                "%player%", args[1])));
                return;
            }
            plugin.getScoreboardManager().toggle(target);
            boolean off = plugin.getScoreboardManager().isToggledOff(target);
            String msg = off ? "toggle-other-disabled" : "toggle-other-enabled";
            sender.sendMessage(plugin.getTextFormatter().format(
                    plugin.getConfigManager().getMessage(msg, "%player%", target.getName())));
        } else {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(plugin.getTextFormatter().format(
                        plugin.getConfigManager().getMessage("player-only")));
                return;
            }
            if (!player.hasPermission("ssscoreboard.toggle")) {
                player.sendMessage(plugin.getTextFormatter().format(
                        plugin.getConfigManager().getMessage("no-permission")));
                return;
            }
            plugin.getScoreboardManager().toggle(player);
            boolean off = plugin.getScoreboardManager().isToggledOff(player);
            String msg = off ? "toggle-disabled" : "toggle-enabled";
            player.sendMessage(plugin.getTextFormatter().format(
                    plugin.getConfigManager().getMessage(msg)));
        }
    }

    private void handleDebug(CommandSender sender) {
        if (!sender.hasPermission("ssscoreboard.debug")) {
            sender.sendMessage(plugin.getTextFormatter().format(
                    plugin.getConfigManager().getMessage("no-permission")));
            return;
        }
        plugin.getDebugManager().toggle();
        boolean enabled = plugin.getDebugManager().isEnabled();
        String msg = enabled ? "debug-enabled" : "debug-disabled";
        sender.sendMessage(plugin.getTextFormatter().format(
                plugin.getConfigManager().getMessage(msg)));
    }

    private void handleInfo(CommandSender sender) {
        sender.sendMessage(plugin.getTextFormatter().format(
                plugin.getConfigManager().getMessage("info-header")));
        sender.sendMessage(plugin.getTextFormatter().format(
                plugin.getConfigManager().getMessage("info-version",
                        "%version%", plugin.getDescription().getVersion())));
        sender.sendMessage(plugin.getTextFormatter().format(
                plugin.getConfigManager().getMessage("info-players",
                        "%count%", String.valueOf(Bukkit.getOnlinePlayers().size()))));
        sender.sendMessage(plugin.getTextFormatter().format(
                plugin.getConfigManager().getMessage("info-worlds",
                        "%worlds%", String.valueOf(plugin.getWorldConfigManager().getLoadedWorldNames().size()))));
    }

    private void handleVersion(CommandSender sender) {
        sender.sendMessage(plugin.getTextFormatter().format(
                plugin.getConfigManager().getMessage("version",
                        "%version%", plugin.getDescription().getVersion())));
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(plugin.getTextFormatter().format(
                plugin.getConfigManager().getMessage("usage")));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subs = Arrays.asList("reload", "toggle", "debug", "info", "version");
            return subs.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .filter(s -> {
                        if (s.equals("reload")) return sender.hasPermission("ssscoreboard.reload");
                        if (s.equals("toggle")) return sender.hasPermission("ssscoreboard.toggle");
                        if (s.equals("debug")) return sender.hasPermission("ssscoreboard.debug");
                        return true;
                    })
                    .collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("toggle")
                && sender.hasPermission("ssscoreboard.toggle.others")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}
