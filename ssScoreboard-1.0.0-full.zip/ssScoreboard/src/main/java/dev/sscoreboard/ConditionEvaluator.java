package dev.sscoreboard;

import org.bukkit.entity.Player;

/**
 * Safe condition evaluator.
 * Supports simple expressions of the form:
 *   %placeholder%=value
 *   %placeholder%!=value
 * Multiple conditions can be chained with & (AND).
 * Does NOT execute arbitrary code.
 */
public class ConditionEvaluator {

    private final SSScoreboard plugin;

    public ConditionEvaluator(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    /**
     * Evaluates a disable-condition string against a player.
     * Returns true if the condition matches (i.e. feature should be disabled).
     * Empty or null condition always returns false (feature stays enabled).
     */
    public boolean evaluate(Player player, String condition) {
        if (condition == null || condition.trim().isEmpty()) {
            return false;
        }

        // Support simple AND with &
        String[] parts = condition.split("&");
        for (String part : parts) {
            part = part.trim();
            if (part.isEmpty()) continue;

            if (!evaluateSingle(player, part)) {
                return false; // AND short-circuit
            }
        }
        return true;
    }

    private boolean evaluateSingle(Player player, String expr) {
        String operator;
        int idx;

        if (expr.contains("!=")) {
            operator = "!=";
            idx = expr.indexOf("!=");
        } else if (expr.contains("=")) {
            operator = "=";
            idx = expr.indexOf("=");
        } else {
            // Bare placeholder – treat as true if non-empty after resolution
            String resolved = plugin.getPlaceholderManager().resolve(player, expr);
            return resolved != null && !resolved.isEmpty() && !resolved.equals(expr);
        }

        String left = expr.substring(0, idx).trim();
        String right = expr.substring(idx + operator.length()).trim();

        String leftResolved = plugin.getPlaceholderManager().resolve(player, left);
        // right side is treated as literal (may still contain placeholders)
        String rightResolved = plugin.getPlaceholderManager().resolve(player, right);

        if (operator.equals("=")) {
            return leftResolved.equalsIgnoreCase(rightResolved);
        } else {
            return !leftResolved.equalsIgnoreCase(rightResolved);
        }
    }
}
