package dev.sscoreboard;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

/**
 * Manages the global config.yml and messages.yml.
 */
public class ConfigManager {

    private final SSScoreboard plugin;
    private FileConfiguration config;
    private FileConfiguration messages;
    private File configFile;
    private File messagesFile;

    public ConfigManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void load() {
        // config.yml
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();

        // messages.yml
        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(messagesFile);

        // Defaults from jar
        InputStream defStream = plugin.getResource("messages.yml");
        if (defStream != null) {
            YamlConfiguration def = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defStream, StandardCharsets.UTF_8));
            messages.setDefaults(def);
        }
    }

    public FileConfiguration getConfig() {
        return config;
    }

    public FileConfiguration getMessages() {
        return messages;
    }

    public String getMessage(String path) {
        String msg = messages.getString(path, path);
        String prefix = messages.getString("prefix", "");
        return msg.replace("%prefix%", prefix);
    }

    public String getMessage(String path, String... replacements) {
        String msg = getMessage(path);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        return msg;
    }

    public void saveMessages() {
        try {
            messages.save(messagesFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save messages.yml", e);
        }
    }

    public boolean isDebugEnabled() {
        return config.getBoolean("debug.enabled", false);
    }

    public boolean isParseShadow() {
        return config.getBoolean("formatting.parse-shadow", true);
    }

    public boolean isParseMiniMessage() {
        return config.getBoolean("formatting.parse-minimessage", true);
    }

    public boolean isParseLegacy() {
        return config.getBoolean("formatting.parse-legacy", true);
    }

    public boolean isParseHex() {
        return config.getBoolean("formatting.parse-hex", true);
    }

    public String getDefaultWorld() {
        return config.getString("default-world", "world");
    }

    public int getUpdateInterval() {
        return config.getInt("scoreboard.update-interval", 20);
    }
}
