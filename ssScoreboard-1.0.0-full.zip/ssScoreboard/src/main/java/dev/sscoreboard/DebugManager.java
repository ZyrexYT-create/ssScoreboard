package dev.sscoreboard;

public class DebugManager {

    private final SSScoreboard plugin;
    private boolean enabled = false;

    public DebugManager(SSScoreboard plugin) {
        this.plugin = plugin;
        this.enabled = plugin.getConfigManager().isDebugEnabled();
    }

    public void toggle() {
        enabled = !enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void log(String message) {
        if (enabled) {
            plugin.getLogger().info("[DEBUG] " + message);
        }
    }
}
