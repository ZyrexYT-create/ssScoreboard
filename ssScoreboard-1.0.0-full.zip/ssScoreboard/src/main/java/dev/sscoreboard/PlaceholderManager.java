package dev.sscoreboard;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Resolves both built-in placeholders and PlaceholderAPI placeholders.
 * Animation placeholders (%animation:Name%) are resolved locally first.
 */
public class PlaceholderManager {

    private final SSScoreboard plugin;
    private boolean placeholderApiAvailable = false;

    private static final Pattern ANIMATION_PATTERN = Pattern.compile("%animation:([a-zA-Z0-9_]+)%");
    private static final Pattern BUILTIN_PATTERN = Pattern.compile("%([a-zA-Z0-9_:]+)%");

    public PlaceholderManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void hook() {
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            placeholderApiAvailable = true;
        }
    }

    public boolean isPlaceholderApiAvailable() {
        return placeholderApiAvailable;
    }

    /**
     * Resolves all placeholders in the given text for the player.
     */
    public String resolve(Player player, String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }

        String result = text;

        // 1. Animation placeholders first (local)
        result = resolveAnimations(result);

        // 2. Built-in placeholders
        result = resolveBuiltins(player, result);

        // 3. PlaceholderAPI (if available)
        if (placeholderApiAvailable && player != null) {
            try {
                result = PlaceholderAPI.setPlaceholders(player, result);
            } catch (Exception e) {
                // Ignore missing expansions
            }
        }

        return result;
    }

    private String resolveAnimations(String text) {
        Matcher matcher = ANIMATION_PATTERN.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String name = matcher.group(1);
            String frame = plugin.getAnimationManager().getCurrentFrame(name);
            matcher.appendReplacement(sb, Matcher.quoteReplacement(frame));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    private String resolveBuiltins(Player player, String text) {
        if (player == null) {
            return text
                    .replace("%server_online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                    .replace("%server_tps%", String.format("%.1f", getTps()))
                    .replace("%server_max%", String.valueOf(Bukkit.getMaxPlayers()));
        }

        return text
                .replace("%player%", player.getName())
                .replace("%displayname%", player.getDisplayName())
                .replace("%world%", player.getWorld().getName())
                .replace("%ping%", String.valueOf(player.getPing()))
                .replace("%server_online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("%server_max%", String.valueOf(Bukkit.getMaxPlayers()))
                .replace("%server_tps%", String.format("%.1f", getTps()))
                .replace("%uuid%", player.getUniqueId().toString());
    }

    private double getTps() {
        try {
            // Paper has getTPS()
            double[] tps = Bukkit.getServer().getTPS();
            if (tps != null && tps.length > 0) {
                return Math.min(20.0, tps[0]);
            }
        } catch (Exception ignored) {
        }
        return 20.0;
    }

    /**
     * Attempts to parse a numeric value from a resolved placeholder string.
     * Returns 0 on failure.
     */
    public int resolveNumeric(Player player, String placeholder) {
        String resolved = resolve(player, placeholder);
        if (resolved == null || resolved.isEmpty()) {
            return 0;
        }
        // Strip non-numeric characters except leading minus and decimal
        String cleaned = resolved.replaceAll("[^0-9.\\-]", "");
        try {
            if (cleaned.contains(".")) {
                return (int) Math.round(Double.parseDouble(cleaned));
            }
            return Integer.parseInt(cleaned);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
