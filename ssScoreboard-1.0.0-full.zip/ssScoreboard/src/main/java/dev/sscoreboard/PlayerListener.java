package dev.sscoreboard;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class PlayerListener implements Listener {

    private final SSScoreboard plugin;

    public PlayerListener(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        // Delay slightly so other plugins can set up
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getScoreboardManager().setupPlayer(event.getPlayer());
            plugin.getTabManager().updatePlayer(event.getPlayer());
            plugin.getTeamManager().updatePlayer(event.getPlayer());
            plugin.getBossBarManager().updatePlayer(event.getPlayer());
        }, 5L);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        plugin.getScoreboardManager().clearPlayer(event.getPlayer());
        plugin.getTabManager().cleanupPlayer(event.getPlayer());
        plugin.getTeamManager().cleanupPlayer(event.getPlayer());
        plugin.getBossBarManager().cleanupPlayer(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent event) {
        // Immediate refresh on world change
        plugin.getScoreboardManager().refreshPlayer(event.getPlayer());
        plugin.getTabManager().updatePlayer(event.getPlayer());
        plugin.getTeamManager().updatePlayer(event.getPlayer());
        plugin.getBossBarManager().updatePlayer(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getScoreboardManager().refreshPlayer(event.getPlayer());
            plugin.getTabManager().updatePlayer(event.getPlayer());
            plugin.getTeamManager().updatePlayer(event.getPlayer());
            plugin.getBossBarManager().updatePlayer(event.getPlayer());
        }, 2L);
    }
}
