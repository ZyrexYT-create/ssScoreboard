package dev.sscoreboard;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class SSScoreboard extends JavaPlugin {

    private static SSScoreboard instance;

    private ConfigManager configManager;
    private WorldConfigManager worldConfigManager;
    private WorldConfigResolver worldConfigResolver;
    private AnimationManager animationManager;
    private PlaceholderManager placeholderManager;
    private TextFormatter textFormatter;
    private ConditionEvaluator conditionEvaluator;
    private ScoreboardManager scoreboardManager;
    private TabManager tabManager;
    private TeamManager teamManager;
    private BossBarManager bossBarManager;
    private CommandManager commandManager;
    private PlayerListener playerListener;
    private UpdateTask updateTask;
    private DebugManager debugManager;

    @Override
    public void onEnable() {
        instance = this;

        // Load configuration first
        configManager = new ConfigManager(this);
        configManager.load();

        // World configs and resolver
        worldConfigManager = new WorldConfigManager(this);
        worldConfigManager.load();
        worldConfigResolver = new WorldConfigResolver(this, worldConfigManager, configManager);

        // Core utilities
        textFormatter = new TextFormatter(this);
        conditionEvaluator = new ConditionEvaluator(this);
        animationManager = new AnimationManager(this);
        animationManager.load();
        placeholderManager = new PlaceholderManager(this);
        placeholderManager.hook();

        // Feature managers
        scoreboardManager = new ScoreboardManager(this);
        tabManager = new TabManager(this);
        teamManager = new TeamManager(this);
        bossBarManager = new BossBarManager(this);
        debugManager = new DebugManager(this);

        // Commands and listeners
        commandManager = new CommandManager(this);
        commandManager.register();
        playerListener = new PlayerListener(this);
        Bukkit.getPluginManager().registerEvents(playerListener, this);

        // Start update task
        updateTask = new UpdateTask(this);
        updateTask.start();

        // Apply to online players (in case of reload)
        Bukkit.getOnlinePlayers().forEach(player -> {
            scoreboardManager.setupPlayer(player);
            tabManager.updatePlayer(player);
            teamManager.updatePlayer(player);
            bossBarManager.updatePlayer(player);
        });

        getLogger().info("ssScoreboard v" + getDescription().getVersion() + " enabled.");
        if (placeholderManager.isPlaceholderApiAvailable()) {
            getLogger().info("PlaceholderAPI hooked successfully.");
        } else {
            getLogger().info("PlaceholderAPI not found – built-in placeholders only.");
        }
    }

    @Override
    public void onDisable() {
        if (updateTask != null) {
            updateTask.stop();
        }
        if (scoreboardManager != null) {
            scoreboardManager.cleanupAll();
        }
        if (tabManager != null) {
            tabManager.cleanupAll();
        }
        if (teamManager != null) {
            teamManager.cleanupAll();
        }
        if (bossBarManager != null) {
            bossBarManager.cleanupAll();
        }
        getLogger().info("ssScoreboard disabled.");
    }

    /**
     * Reloads all configuration and refreshes displays.
     * @return true if reload succeeded
     */
    public boolean reload() {
        try {
            configManager.load();
            worldConfigManager.load();
            animationManager.load();
            worldConfigResolver.invalidateCache();

            // Restart update task with possibly new interval
            if (updateTask != null) {
                updateTask.stop();
            }
            updateTask = new UpdateTask(this);
            updateTask.start();

            // Refresh all online players
            Bukkit.getOnlinePlayers().forEach(player -> {
                scoreboardManager.refreshPlayer(player);
                tabManager.updatePlayer(player);
                teamManager.updatePlayer(player);
                bossBarManager.updatePlayer(player);
            });

            return true;
        } catch (Exception e) {
            getLogger().severe("Reload failed: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public static SSScoreboard getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public WorldConfigManager getWorldConfigManager() {
        return worldConfigManager;
    }

    public WorldConfigResolver getWorldConfigResolver() {
        return worldConfigResolver;
    }

    public AnimationManager getAnimationManager() {
        return animationManager;
    }

    public PlaceholderManager getPlaceholderManager() {
        return placeholderManager;
    }

    public TextFormatter getTextFormatter() {
        return textFormatter;
    }

    public ConditionEvaluator getConditionEvaluator() {
        return conditionEvaluator;
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public TabManager getTabManager() {
        return tabManager;
    }

    public TeamManager getTeamManager() {
        return teamManager;
    }

    public BossBarManager getBossBarManager() {
        return bossBarManager;
    }

    public DebugManager getDebugManager() {
        return debugManager;
    }

    public UpdateTask getUpdateTask() {
        return updateTask;
    }
}
