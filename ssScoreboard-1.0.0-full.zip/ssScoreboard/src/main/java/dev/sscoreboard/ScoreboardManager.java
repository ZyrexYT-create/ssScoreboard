package dev.sscoreboard;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages per-player sidebar scoreboards.
 * Uses a single shared objective name to avoid duplicates.
 * Lines are set via teams with unique prefixes to support duplicate visual lines.
 */
public class ScoreboardManager {

    private final SSScoreboard plugin;
    private final Map<UUID, PlayerScoreboardData> playerData = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> toggledOff = new ConcurrentHashMap<>();

    private static final String OBJECTIVE_NAME = "sss_sidebar";
    private static final String[] LINE_ENTRIES = {
            "§0", "§1", "§2", "§3", "§4", "§5", "§6", "§7", "§8", "§9",
            "§a", "§b", "§c", "§d", "§e", "§f"
    };

    public ScoreboardManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void setupPlayer(Player player) {
        if (isToggledOff(player)) {
            return;
        }
        String world = player.getWorld().getName();
        if (!plugin.getWorldConfigResolver().isScoreboardEnabled(world)) {
            clearPlayer(player);
            return;
        }
        String condition = plugin.getWorldConfigResolver().getDisableCondition(world, "scoreboard");
        if (plugin.getConditionEvaluator().evaluate(player, condition)) {
            clearPlayer(player);
            return;
        }

        PlayerScoreboardData data = playerData.computeIfAbsent(player.getUniqueId(),
                uuid -> new PlayerScoreboardData());

        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = board.registerNewObjective(OBJECTIVE_NAME, Criteria.DUMMY,
                Component.text(" "));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        data.scoreboard = board;
        data.objective = objective;
        data.worldName = world;

        player.setScoreboard(board);
        updateLines(player);
    }

    public void refreshPlayer(Player player) {
        if (isToggledOff(player)) {
            clearPlayer(player);
            return;
        }
        String world = player.getWorld().getName();
        PlayerScoreboardData data = playerData.get(player.getUniqueId());

        if (!plugin.getWorldConfigResolver().isScoreboardEnabled(world)) {
            clearPlayer(player);
            return;
        }

        if (data == null || data.scoreboard == null || !data.worldName.equals(world)) {
            setupPlayer(player);
            return;
        }
        updateLines(player);
    }

    public void updateLines(Player player) {
        PlayerScoreboardData data = playerData.get(player.getUniqueId());
        if (data == null || data.objective == null) {
            return;
        }

        String world = player.getWorld().getName();
        String titleRaw = plugin.getWorldConfigResolver().getScoreboardTitle(world);
        List<String> lines = plugin.getWorldConfigResolver().getScoreboardLines(world);

        // Title
        String titleResolved = plugin.getPlaceholderManager().resolve(player, titleRaw);
        Component titleComp = plugin.getTextFormatter().format(titleResolved);
        data.objective.displayName(titleComp);

        // Clear previous scores
        for (String entry : data.scoreboard.getEntries()) {
            data.scoreboard.resetScores(entry);
        }

        // Apply lines (max 15 for sidebar)
        int score = Math.min(lines.size(), LINE_ENTRIES.length);
        for (int i = 0; i < score; i++) {
            String lineRaw = lines.get(i);
            String resolved = plugin.getPlaceholderManager().resolve(player, lineRaw);
            // Use unique entry keys to allow duplicate visual content
            String entry = LINE_ENTRIES[i];
            // Set the score
            data.objective.getScore(entry).setScore(score - i);

            // Use a team to set the prefix/suffix for display text
            String teamName = "sss_l" + i;
            org.bukkit.scoreboard.Team team = data.scoreboard.getTeam(teamName);
            if (team == null) {
                team = data.scoreboard.registerNewTeam(teamName);
            }
            team.prefix(plugin.getTextFormatter().format(resolved));
            team.suffix(Component.empty());
            if (!team.hasEntry(entry)) {
                team.addEntry(entry);
            }
        }
    }

    public void clearPlayer(Player player) {
        PlayerScoreboardData data = playerData.remove(player.getUniqueId());
        if (data != null && data.scoreboard != null) {
            // Reset to main scoreboard
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
    }

    public void cleanupAll() {
        for (UUID uuid : playerData.keySet()) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) {
                clearPlayer(player);
            }
        }
        playerData.clear();
    }

    public void toggle(Player player) {
        boolean currentlyOff = isToggledOff(player);
        if (currentlyOff) {
            toggledOff.remove(player.getUniqueId());
            setupPlayer(player);
        } else {
            toggledOff.put(player.getUniqueId(), true);
            clearPlayer(player);
        }
    }

    public boolean isToggledOff(Player player) {
        return Boolean.TRUE.equals(toggledOff.get(player.getUniqueId()));
    }

    public void setToggledOff(Player player, boolean off) {
        if (off) {
            toggledOff.put(player.getUniqueId(), true);
            clearPlayer(player);
        } else {
            toggledOff.remove(player.getUniqueId());
            setupPlayer(player);
        }
    }

    private static class PlayerScoreboardData {
        Scoreboard scoreboard;
        Objective objective;
        String worldName;
    }
}
