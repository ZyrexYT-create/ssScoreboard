package dev.sscoreboard;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages TAB header/footer and player list name formatting.
 */
public class TabManager {

    private final SSScoreboard plugin;
    private final Map<UUID, String> lastHeader = new ConcurrentHashMap<>();
    private final Map<UUID, String> lastFooter = new ConcurrentHashMap<>();

    public TabManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void updatePlayer(Player player) {
        String world = player.getWorld().getName();

        // Header / Footer
        if (plugin.getWorldConfigResolver().isHeaderFooterEnabled(world)) {
            String condition = plugin.getWorldConfigResolver().getDisableCondition(world, "header-footer");
            if (!plugin.getConditionEvaluator().evaluate(player, condition)) {
                updateHeaderFooter(player, world);
            } else {
                clearHeaderFooter(player);
            }
        } else {
            clearHeaderFooter(player);
        }

        // Player list name
        if (plugin.getWorldConfigResolver().isTabNameFormattingEnabled(world)) {
            String condition = plugin.getWorldConfigResolver().getDisableCondition(world, "tablist-name-formatting");
            if (!plugin.getConditionEvaluator().evaluate(player, condition)) {
                updateListName(player, world);
            } else {
                player.playerListName(null); // reset
            }
        }
    }

    private void updateHeaderFooter(Player player, String world) {
        List<String> headerLines = plugin.getWorldConfigResolver().getHeader(world);
        List<String> footerLines = plugin.getWorldConfigResolver().getFooter(world);

        Component header = buildMultiline(player, headerLines);
        Component footer = buildMultiline(player, footerLines);

        player.sendPlayerListHeaderAndFooter(header, footer);
    }

    private Component buildMultiline(Player player, List<String> lines) {
        if (lines == null || lines.isEmpty()) {
            return Component.empty();
        }
        Component result = Component.empty();
        for (int i = 0; i < lines.size(); i++) {
            String resolved = plugin.getPlaceholderManager().resolve(player, lines.get(i));
            Component line = plugin.getTextFormatter().format(resolved);
            if (i == 0) {
                result = line;
            } else {
                result = result.append(Component.newline()).append(line);
            }
        }
        return result;
    }

    private void updateListName(Player player, String world) {
        String format = plugin.getWorldConfigResolver().getTabNameFormat(world);
        String resolved = plugin.getPlaceholderManager().resolve(player, format);
        Component name = plugin.getTextFormatter().format(resolved);
        player.playerListName(name);
    }

    private void clearHeaderFooter(Player player) {
        player.sendPlayerListHeaderAndFooter(Component.empty(), Component.empty());
    }

    public void cleanupPlayer(Player player) {
        lastHeader.remove(player.getUniqueId());
        lastFooter.remove(player.getUniqueId());
        // Don't forcibly clear header/footer on quit – client handles it
    }

    public void cleanupAll() {
        lastHeader.clear();
        lastFooter.clear();
    }
}
