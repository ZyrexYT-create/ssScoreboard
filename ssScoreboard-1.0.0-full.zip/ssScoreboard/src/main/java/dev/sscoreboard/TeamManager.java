package dev.sscoreboard;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages scoreboard teams for sorting and nametag visibility.
 * Uses the player's current scoreboard (created by ScoreboardManager) when possible.
 * Falls back to main scoreboard carefully to avoid conflicts.
 */
public class TeamManager {

    private final SSScoreboard plugin;
    private final Map<UUID, String> playerTeam = new ConcurrentHashMap<>();

    public TeamManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void updatePlayer(Player player) {
        String world = player.getWorld().getName();
        if (!plugin.getWorldConfigResolver().isTeamsEnabled(world)) {
            removeFromTeams(player);
            return;
        }

        String condition = plugin.getWorldConfigResolver().getDisableCondition(world, "scoreboard-teams");
        if (plugin.getConditionEvaluator().evaluate(player, condition)) {
            removeFromTeams(player);
            return;
        }

        Scoreboard board = player.getScoreboard();
        if (board == null || board == Bukkit.getScoreboardManager().getMainScoreboard()) {
            // ScoreboardManager should have set a custom one; if not, skip
            return;
        }

        String sortKey = computeSortKey(player, world);
        String teamName = "sss_" + sanitize(sortKey);

        // Ensure team exists
        Team team = board.getTeam(teamName);
        if (team == null) {
            team = board.registerNewTeam(teamName);
            applyTeamOptions(team, world);
        }

        // Remove from previous team if different
        String previous = playerTeam.get(player.getUniqueId());
        if (previous != null && !previous.equals(teamName)) {
            Team old = board.getTeam(previous);
            if (old != null) {
                old.removeEntry(player.getName());
            }
        }

        if (!team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
        }
        playerTeam.put(player.getUniqueId(), teamName);
    }

    private void applyTeamOptions(Team team, String world) {
        var cfg = plugin.getWorldConfigResolver().resolve(world);
        boolean collision = cfg.getBoolean("scoreboard-teams.enable-collision", true);
        boolean invisible = cfg.getBoolean("scoreboard-teams.invisible-nametags", false);
        boolean friendly = cfg.getBoolean("scoreboard-teams.can-see-friendly-invisibles", false);

        team.setOption(Team.Option.COLLISION_RULE,
                collision ? Team.OptionStatus.ALWAYS : Team.OptionStatus.NEVER);
        team.setOption(Team.Option.NAME_TAG_VISIBILITY,
                invisible ? Team.OptionStatus.NEVER : Team.OptionStatus.ALWAYS);
        team.setCanSeeFriendlyInvisibles(friendly);
    }

    private String computeSortKey(Player player, String world) {
        var cfg = plugin.getWorldConfigResolver().resolve(world);
        List<String> sortingTypes = cfg.getStringList("scoreboard-teams.sorting-types");
        if (sortingTypes.isEmpty()) {
            return "default_" + player.getName();
        }

        StringBuilder key = new StringBuilder();
        for (String type : sortingTypes) {
            if (type.startsWith("GROUPS:")) {
                String groups = type.substring(7);
                String[] order = groups.split(",");
                String playerGroup = getPrimaryGroup(player);
                int idx = Arrays.asList(order).indexOf(playerGroup);
                if (idx < 0) idx = order.length;
                key.append(String.format("%03d", idx));
            } else if (type.startsWith("PLACEHOLDER_A_TO_Z:")) {
                String ph = type.substring(19);
                String resolved = plugin.getPlaceholderManager().resolve(player, ph);
                key.append(resolved != null ? resolved.toLowerCase() : "");
            } else {
                key.append(player.getName().toLowerCase());
            }
            key.append("_");
        }
        return key.toString();
    }

    private String getPrimaryGroup(Player player) {
        // Try LuckPerms via PlaceholderAPI if available
        String prefix = plugin.getPlaceholderManager().resolve(player, "%luckperms_primary_group%");
        if (prefix != null && !prefix.startsWith("%")) {
            return prefix.toLowerCase();
        }
        // Fallback: permission-based guess
        if (player.hasPermission("group.owner")) return "owner";
        if (player.hasPermission("group.admin")) return "admin";
        if (player.hasPermission("group.mod")) return "mod";
        if (player.hasPermission("group.helper")) return "helper";
        return "default";
    }

    private String sanitize(String input) {
        // Team names limited to 16 chars in older versions; keep safe
        String s = input.replaceAll("[^a-zA-Z0-9_]", "");
        if (s.length() > 12) {
            s = s.substring(0, 12);
        }
        return s.isEmpty() ? "def" : s;
    }

    private void removeFromTeams(Player player) {
        String teamName = playerTeam.remove(player.getUniqueId());
        if (teamName == null) return;
        Scoreboard board = player.getScoreboard();
        if (board != null) {
            Team team = board.getTeam(teamName);
            if (team != null) {
                team.removeEntry(player.getName());
            }
        }
    }

    public void cleanupPlayer(Player player) {
        removeFromTeams(player);
    }

    public void cleanupAll() {
        playerTeam.clear();
    }
}
