package dev.sscoreboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.TextComponent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles legacy colors, hex colors, MiniMessage, and custom shadow tags.
 * Shadow tags are converted to a closest compatible Adventure representation
 * (colored text with optional bold) because native client text-shadow is limited.
 */
public class TextFormatter {

    private final SSScoreboard plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final LegacyComponentSerializer legacyAmpersand =
            LegacyComponentSerializer.legacyAmpersand();
    private final LegacyComponentSerializer legacySection =
            LegacyComponentSerializer.legacySection();

    // &#RRGGBB
    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    // <shadow:RRGGBB> ... (custom)
    private static final Pattern SHADOW_PATTERN = Pattern.compile(
            "<shadow:([A-Fa-f0-9]{6})>(.*?)(?=<shadow:|/shadow>|$)", Pattern.DOTALL);
    // Simple MiniMessage-like tags we support when MiniMessage is partially used
    private static final Pattern SIMPLE_TAG = Pattern.compile("<(/?)(red|green|blue|yellow|gold|aqua|white|gray|dark_gray|black|bold|italic|underlined|strikethrough|obfuscated)>");

    public TextFormatter(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    /**
     * Formats a raw string (with placeholders already resolved) into an Adventure Component.
     */
    public Component format(String input) {
        if (input == null || input.isEmpty()) {
            return Component.empty();
        }

        String text = input;

        // 1. Handle custom <shadow:RRGGBB> tags first – convert to colored text
        if (plugin.getConfigManager().isParseShadow()) {
            text = processShadowTags(text);
        }

        // 2. Convert &#RRGGBB to MiniMessage <#RRGGBB> or legacy if needed
        if (plugin.getConfigManager().isParseHex()) {
            text = convertHexToMiniMessage(text);
        }

        // 3. Convert legacy & codes to section or leave for serializer
        // We prefer MiniMessage path when possible
        try {
            if (plugin.getConfigManager().isParseMiniMessage()) {
                // Translate remaining legacy & to MiniMessage equivalents where simple
                text = legacyToApproximateMini(text);
                return miniMessage.deserialize(text);
            }
        } catch (Exception e) {
            // Fall through to legacy
        }

        // Fallback: legacy ampersand
        if (plugin.getConfigManager().isParseLegacy()) {
            return legacyAmpersand.deserialize(text);
        }

        return Component.text(text);
    }

    /**
     * Formats to a legacy string (useful for some scoreboard APIs that still expect strings).
     */
    public String formatToLegacy(String input) {
        Component component = format(input);
        return legacySection.serialize(component);
    }

    private String processShadowTags(String input) {
        // Replace <shadow:RRGGBB>content with colored content (closest approximation)
        Matcher matcher = SHADOW_PATTERN.matcher(input);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String color = matcher.group(1);
            String content = matcher.group(2);
            // Approximate shadow by applying the color + bold
            String replacement = "<#" + color + "><bold>" + content + "</bold></#" + color + ">";
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(sb);
        // Also strip any leftover closing tags
        return sb.toString().replace("</shadow>", "");
    }

    private String convertHexToMiniMessage(String input) {
        Matcher matcher = HEX_PATTERN.matcher(input);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String hex = matcher.group(1);
            matcher.appendReplacement(sb, "<#" + hex + ">");
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    private String legacyToApproximateMini(String input) {
        // Simple replacement of common & codes to MiniMessage
        String s = input
                .replace("&0", "<black>")
                .replace("&1", "<dark_blue>")
                .replace("&2", "<dark_green>")
                .replace("&3", "<dark_aqua>")
                .replace("&4", "<dark_red>")
                .replace("&5", "<dark_purple>")
                .replace("&6", "<gold>")
                .replace("&7", "<gray>")
                .replace("&8", "<dark_gray>")
                .replace("&9", "<blue>")
                .replace("&a", "<green>")
                .replace("&b", "<aqua>")
                .replace("&c", "<red>")
                .replace("&d", "<light_purple>")
                .replace("&e", "<yellow>")
                .replace("&f", "<white>")
                .replace("&l", "<bold>")
                .replace("&o", "<italic>")
                .replace("&n", "<underlined>")
                .replace("&m", "<strikethrough>")
                .replace("&k", "<obfuscated>")
                .replace("&r", "<reset>");
        return s;
    }

    /**
     * Utility to strip all formatting codes for length checks etc.
     */
    public String stripFormatting(String input) {
        if (input == null) return "";
        String s = input.replaceAll("&#[A-Fa-f0-9]{6}", "");
        s = s.replaceAll("&[0-9a-fk-or]", "");
        s = s.replaceAll("<[^>]+>", "");
        return s;
    }
}
