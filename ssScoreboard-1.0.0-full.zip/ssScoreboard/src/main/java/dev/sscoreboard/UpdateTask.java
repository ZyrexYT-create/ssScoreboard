package dev.sscoreboard;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/**
 * Single centralized repeating task that:
 * - Advances animations
 * - Refreshes scoreboards, TAB, teams, and bossbars for online players
 *
 * Avoids per-player or per-animation tasks.
 */
public class UpdateTask implements Runnable {

    private final SSScoreboard plugin;
    private BukkitTask task;
    private int tickCounter = 0;

    public UpdateTask(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void start() {
        int interval = Math.max(1, plugin.getConfigManager().getUpdateInterval());
        task = Bukkit.getScheduler().runTaskTimer(plugin, this, interval, interval);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    @Override
    public void run() {
        tickCounter++;

        // Always advance animations (they use their own intervals)
        plugin.getAnimationManager().tick();

        // Refresh players
        for (Player player : Bukkit.getOnlinePlayers()) {
            try {
                // Scoreboard lines (title + placeholders)
                if (!plugin.getScoreboardManager().isToggledOff(player)) {
                    plugin.getScoreboardManager().updateLines(player);
                }

                // TAB header/footer and list name
                plugin.getTabManager().updatePlayer(player);

                // Teams (group changes etc.)
                plugin.getTeamManager().updatePlayer(player);

                // Bossbars
                plugin.getBossBarManager().updatePlayer(player);
            } catch (Exception e) {
                if (plugin.getDebugManager().isEnabled()) {
                    plugin.getLogger().warning("Update error for " + player.getName() + ": " + e.getMessage());
                }
            }
        }
    }
}
