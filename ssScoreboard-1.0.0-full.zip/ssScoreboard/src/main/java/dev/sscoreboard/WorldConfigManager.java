package dev.sscoreboard;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;

/**
 * Loads and stores per-world YAML configuration files from the worlds/ folder.
 */
public class WorldConfigManager {

    private final SSScoreboard plugin;
    private final Map<String, FileConfiguration> worldConfigs = new HashMap<>();
    private File worldsFolder;

    public WorldConfigManager(SSScoreboard plugin) {
        this.plugin = plugin;
    }

    public void load() {
        worldConfigs.clear();
        worldsFolder = new File(plugin.getDataFolder(), "worlds");
        if (!worldsFolder.exists()) {
            worldsFolder.mkdirs();
        }

        // Copy default world files from jar if missing
        copyDefaultIfMissing("world.yml");
        copyDefaultIfMissing("world_nether.yml");
        copyDefaultIfMissing("world_the_end.yml");

        File[] files = worldsFolder.listFiles((dir, name) -> name.endsWith(".yml"));
        if (files != null) {
            for (File file : files) {
                String worldName = file.getName().substring(0, file.getName().length() - 4);
                try {
                    FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
                    worldConfigs.put(worldName, cfg);
                    if (plugin.getConfigManager().isDebugEnabled()) {
                        plugin.getLogger().info("Loaded world config: " + worldName);
                    }
                } catch (Exception e) {
                    plugin.getLogger().log(Level.WARNING, "Failed to load world config: " + file.getName(), e);
                }
            }
        }
    }

    private void copyDefaultIfMissing(String resourceName) {
        File target = new File(worldsFolder, resourceName);
        if (!target.exists()) {
            try {
                plugin.saveResource("worlds/" + resourceName, false);
            } catch (IllegalArgumentException e) {
                // Resource may not exist in jar for custom worlds – ignore
            }
        }
    }

    /**
     * Returns the raw FileConfiguration for a world name, or null if none exists.
     */
    public FileConfiguration getRawConfig(String worldName) {
        return worldConfigs.get(worldName);
    }

    public boolean hasConfig(String worldName) {
        return worldConfigs.containsKey(worldName);
    }

    public Set<String> getLoadedWorldNames() {
        return Collections.unmodifiableSet(worldConfigs.keySet());
    }

    public Map<String, FileConfiguration> getAllConfigs() {
        return Collections.unmodifiableMap(worldConfigs);
    }

    /**
     * Creates an empty world config file for a new world if auto-create is enabled.
     */
    public void createIfAbsent(String worldName) {
        if (worldConfigs.containsKey(worldName)) {
            return;
        }
        boolean autoCreate = plugin.getConfig().getBoolean("world-config.auto-create", true);
        if (!autoCreate) {
            return;
        }
        File file = new File(worldsFolder, worldName + ".yml");
        if (file.exists()) {
            return;
        }
        try {
            FileConfiguration cfg = new YamlConfiguration();
            cfg.options().header("Auto-generated world config for " + worldName + "\n" +
                    "Remove this file or leave empty to fully inherit from default world.");
            cfg.save(file);
            worldConfigs.put(worldName, cfg);
            plugin.getLogger().info("Auto-created world config: " + worldName + ".yml");
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Could not auto-create world config for " + worldName, e);
        }
    }
}
