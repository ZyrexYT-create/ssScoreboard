package dev.sscoreboard;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Resolves effective configuration for any world using the mandatory fallback priority:
 * 1. Exact world config
 * 2. Default "world" config
 * 3. Global config.yml defaults
 *
 * Performs recursive section merging so that a world can override only specific keys
 * while inheriting the rest.
 */
public class WorldConfigResolver {

    private final SSScoreboard plugin;
    private final WorldConfigManager worldConfigManager;
    private final ConfigManager configManager;

    /** Cache of fully merged configs per world name */
    private final Map<String, FileConfiguration> resolvedCache = new ConcurrentHashMap<>();

    public WorldConfigResolver(SSScoreboard plugin, WorldConfigManager worldConfigManager, ConfigManager configManager) {
        this.plugin = plugin;
        this.worldConfigManager = worldConfigManager;
        this.configManager = configManager;
    }

    public void invalidateCache() {
        resolvedCache.clear();
    }

    /**
     * Returns the fully resolved (merged) configuration for the given world name.
     */
    public FileConfiguration resolve(String worldName) {
        if (worldName == null || worldName.isEmpty()) {
            worldName = configManager.getDefaultWorld();
        }

        FileConfiguration cached = resolvedCache.get(worldName);
        if (cached != null) {
            return cached;
        }

        FileConfiguration result = mergeConfigs(worldName);
        resolvedCache.put(worldName, result);
        return result;
    }

    private FileConfiguration mergeConfigs(String worldName) {
        FileConfiguration global = configManager.getConfig();
        FileConfiguration defaultWorld = worldConfigManager.getRawConfig(configManager.getDefaultWorld());
        FileConfiguration specific = worldConfigManager.getRawConfig(worldName);

        // Start from global as base
        FileConfiguration merged = new YamlConfiguration();
        deepCopySection(global, merged);

        // Overlay default world config (if different from requested and exists)
        if (defaultWorld != null && !worldName.equals(configManager.getDefaultWorld())) {
            deepMerge(defaultWorld, merged);
        } else if (defaultWorld != null && worldName.equals(configManager.getDefaultWorld())) {
            deepMerge(defaultWorld, merged);
        }

        // Overlay specific world config (highest priority)
        if (specific != null && !worldName.equals(configManager.getDefaultWorld())) {
            deepMerge(specific, merged);
        } else if (specific != null) {
            // Already handled above when it is the default
        }

        return merged;
    }

    /**
     * Recursively merges source into target.
     * - Scalar values: source overrides target when present.
     * - Lists: source list replaces target list when the key is explicitly present in source.
     * - Sections: recursively merged.
     * - Missing keys in source: leave target unchanged (inherit).
     */
    public void deepMerge(ConfigurationSection source, ConfigurationSection target) {
        if (source == null) {
            return;
        }
        for (String key : source.getKeys(false)) {
            Object srcVal = source.get(key);
            if (srcVal instanceof ConfigurationSection) {
                ConfigurationSection srcSec = (ConfigurationSection) srcVal;
                ConfigurationSection tgtSec = target.getConfigurationSection(key);
                if (tgtSec == null) {
                    tgtSec = target.createSection(key);
                }
                deepMerge(srcSec, tgtSec);
            } else if (srcVal instanceof List) {
                // Explicit list replaces
                target.set(key, new ArrayList<>((List<?>) srcVal));
            } else {
                // Scalar or other – override
                target.set(key, srcVal);
            }
        }
    }

    private void deepCopySection(ConfigurationSection source, ConfigurationSection target) {
        if (source == null) {
            return;
        }
        for (String key : source.getKeys(false)) {
            Object val = source.get(key);
            if (val instanceof ConfigurationSection) {
                ConfigurationSection newSec = target.createSection(key);
                deepCopySection((ConfigurationSection) val, newSec);
            } else if (val instanceof List) {
                target.set(key, new ArrayList<>((List<?>) val));
            } else {
                target.set(key, val);
            }
        }
    }

    // Convenience accessors for common sections

    public boolean isScoreboardEnabled(String worldName) {
        FileConfiguration cfg = resolve(worldName);
        // Only treat as disabled when the key is explicitly present and false
        if (cfg.isSet("scoreboard.enabled")) {
            return cfg.getBoolean("scoreboard.enabled");
        }
        return true; // default enabled
    }

    public boolean isHeaderFooterEnabled(String worldName) {
        FileConfiguration cfg = resolve(worldName);
        if (cfg.isSet("header-footer.enabled")) {
            return cfg.getBoolean("header-footer.enabled");
        }
        return true;
    }

    public boolean isTabNameFormattingEnabled(String worldName) {
        FileConfiguration cfg = resolve(worldName);
        if (cfg.isSet("tablist-name-formatting.enabled")) {
            return cfg.getBoolean("tablist-name-formatting.enabled");
        }
        return true;
    }

    public boolean isTeamsEnabled(String worldName) {
        FileConfiguration cfg = resolve(worldName);
        if (cfg.isSet("scoreboard-teams.enabled")) {
            return cfg.getBoolean("scoreboard-teams.enabled");
        }
        return true;
    }

    public boolean isPlayerListObjectiveEnabled(String worldName) {
        FileConfiguration cfg = resolve(worldName);
        if (cfg.isSet("playerlist-objective.enabled")) {
            return cfg.getBoolean("playerlist-objective.enabled");
        }
        return false;
    }

    public boolean isBelowNameObjectiveEnabled(String worldName) {
        FileConfiguration cfg = resolve(worldName);
        if (cfg.isSet("belowname-objective.enabled")) {
            return cfg.getBoolean("belowname-objective.enabled");
        }
        return true;
    }

    public boolean isBossBarEnabled(String worldName) {
        FileConfiguration cfg = resolve(worldName);
        if (cfg.isSet("bossbar.enabled")) {
            return cfg.getBoolean("bossbar.enabled");
        }
        return true;
    }

    public String getScoreboardTitle(String worldName) {
        return resolve(worldName).getString("scoreboard.title", "");
    }

    public List<String> getScoreboardLines(String worldName) {
        return resolve(worldName).getStringList("scoreboard.lines");
    }

    public List<String> getHeader(String worldName) {
        return resolve(worldName).getStringList("header-footer.header");
    }

    public List<String> getFooter(String worldName) {
        return resolve(worldName).getStringList("header-footer.footer");
    }

    public String getTabNameFormat(String worldName) {
        return resolve(worldName).getString("tablist-name-formatting.format", "%player%");
    }

    public String getDisableCondition(String worldName, String section) {
        return resolve(worldName).getString(section + ".disable-condition", "");
    }

    public int getUpdateInterval(String worldName) {
        return resolve(worldName).getInt("scoreboard.update-interval", configManager.getUpdateInterval());
    }
}
