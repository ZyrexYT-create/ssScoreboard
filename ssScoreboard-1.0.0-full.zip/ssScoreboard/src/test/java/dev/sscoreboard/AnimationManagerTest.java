package dev.sscoreboard;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AnimationManagerTest {

    @Test
    void animationAdvancesOnInterval() {
        AnimationManager.Animation anim = new AnimationManager.Animation(
                "Test", 5, List.of("A", "B", "C"));

        assertEquals("A", anim.getCurrentText());

        anim.advanceIfNeeded(5);
        assertEquals("B", anim.getCurrentText());

        anim.advanceIfNeeded(10);
        assertEquals("C", anim.getCurrentText());

        anim.advanceIfNeeded(15);
        assertEquals("A", anim.getCurrentText()); // wraps
    }

    @Test
    void animationDoesNotAdvanceEarly() {
        AnimationManager.Animation anim = new AnimationManager.Animation(
                "Test", 10, List.of("X", "Y"));

        assertEquals("X", anim.getCurrentText());
        anim.advanceIfNeeded(5);
        assertEquals("X", anim.getCurrentText());
        anim.advanceIfNeeded(9);
        assertEquals("X", anim.getCurrentText());
        anim.advanceIfNeeded(10);
        assertEquals("Y", anim.getCurrentText());
    }

    @Test
    void emptyTextsSafe() {
        AnimationManager.Animation anim = new AnimationManager.Animation(
                "Empty", 20, List.of());
        assertEquals("", anim.getCurrentText());
    }
}
