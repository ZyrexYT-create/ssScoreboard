package dev.sscoreboard;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests the pure logic of condition parsing without requiring a Player.
 * The full evaluator needs PlaceholderManager; here we test the expression structure.
 */
public class ConditionEvaluatorTest {

    @Test
    void emptyConditionIsFalse() {
        assertFalse(evaluateEmpty(null));
        assertFalse(evaluateEmpty(""));
        assertFalse(evaluateEmpty("   "));
    }

    @Test
    void simpleEqualityStructure() {
        String expr = "%world%=disabledworld";
        assertTrue(expr.contains("="));
        assertFalse(expr.contains("!="));
        int idx = expr.indexOf("=");
        String left = expr.substring(0, idx).trim();
        String right = expr.substring(idx + 1).trim();
        assertEquals("%world%", left);
        assertEquals("disabledworld", right);
    }

    @Test
    void inequalityStructure() {
        String expr = "%world%!=lobby";
        assertTrue(expr.contains("!="));
        int idx = expr.indexOf("!=");
        String left = expr.substring(0, idx).trim();
        String right = expr.substring(idx + 2).trim();
        assertEquals("%world%", left);
        assertEquals("lobby", right);
    }

    @Test
    void andChaining() {
        String condition = "%world%=nether&%player%=Steve";
        String[] parts = condition.split("&");
        assertEquals(2, parts.length);
        assertEquals("%world%=nether", parts[0].trim());
        assertEquals("%player%=Steve", parts[1].trim());
    }

    private boolean evaluateEmpty(String condition) {
        return condition != null && !condition.trim().isEmpty();
    }
}
