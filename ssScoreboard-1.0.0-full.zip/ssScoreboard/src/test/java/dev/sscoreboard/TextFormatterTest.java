package dev.sscoreboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Basic tests for formatting helpers.
 * Full Adventure deserialization requires more setup; we test the pure string transforms.
 */
public class TextFormatterTest {

    @Test
    void hexPatternConversion() {
        String input = "&#00B8FFHello &#FF0000World";
        // Simulate the conversion used in TextFormatter
        java.util.regex.Pattern HEX = java.util.regex.Pattern.compile("&#([A-Fa-f0-9]{6})");
        java.util.regex.Matcher m = HEX.matcher(input);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            m.appendReplacement(sb, "<#" + m.group(1) + ">");
        }
        m.appendTail(sb);
        String result = sb.toString();
        assertTrue(result.contains("<#00B8FF>"));
        assertTrue(result.contains("<#FF0000>"));
        assertFalse(result.contains("&#"));
    }

    @Test
    void stripFormattingRemovesCodes() {
        String input = "&#00B8FF&lBold &cRed <shadow:0000FF>Text";
        String stripped = input
                .replaceAll("&#[A-Fa-f0-9]{6}", "")
                .replaceAll("&[0-9a-fk-or]", "")
                .replaceAll("<[^>]+>", "");
        assertEquals("Bold Red Text", stripped);
    }

    @Test
    void legacyColorPresence() {
        String input = "&aGreen &lBold &rReset";
        assertTrue(input.contains("&a"));
        assertTrue(input.contains("&l"));
    }
}
