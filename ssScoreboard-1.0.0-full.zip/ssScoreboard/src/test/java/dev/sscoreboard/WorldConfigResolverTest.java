package dev.sscoreboard;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for world configuration fallback and recursive merging.
 * These tests use pure YamlConfiguration objects and do not require a running server.
 */
public class WorldConfigResolverTest {

    private YamlConfiguration global;
    private YamlConfiguration worldDefault;
    private YamlConfiguration nether;
    private YamlConfiguration end;

    @BeforeEach
    void setUp() {
        global = new YamlConfiguration();
        global.set("scoreboard.enabled", true);
        global.set("scoreboard.title", "Global Title");
        global.set("scoreboard.lines", java.util.List.of("Global Line 1", "Global Line 2"));
        global.set("header-footer.enabled", true);
        global.set("header-footer.header", java.util.List.of("Global Header"));
        global.set("header-footer.footer", java.util.List.of("Global Footer"));
        global.set("bossbar.enabled", true);

        worldDefault = new YamlConfiguration();
        worldDefault.set("scoreboard.enabled", true);
        worldDefault.set("scoreboard.title", "World Title");
        worldDefault.set("scoreboard.lines", java.util.List.of("World Line 1"));
        worldDefault.set("header-footer.enabled", true);
        worldDefault.set("header-footer.header", java.util.List.of("World Header"));
        worldDefault.set("header-footer.footer", java.util.List.of("World Footer"));

        nether = new YamlConfiguration();
        nether.set("scoreboard.enabled", true);
        nether.set("scoreboard.title", "Nether Title");
        // No header-footer → should inherit

        end = new YamlConfiguration();
        end.set("scoreboard.enabled", false);
        // Explicitly disabled scoreboard
    }

    @Test
    void exactWorldConfigTakesPriority() {
        YamlConfiguration merged = new YamlConfiguration();
        deepMerge(global, merged);
        deepMerge(worldDefault, merged);
        deepMerge(nether, merged);

        assertEquals("Nether Title", merged.getString("scoreboard.title"));
        // Inherited from world
        assertEquals(java.util.List.of("World Header"), merged.getStringList("header-footer.header"));
    }

    @Test
    void netherFallsBackToWorld() {
        YamlConfiguration merged = new YamlConfiguration();
        deepMerge(global, merged);
        deepMerge(worldDefault, merged);
        // No nether overlay

        assertEquals("World Title", merged.getString("scoreboard.title"));
        assertEquals(java.util.List.of("World Header"), merged.getStringList("header-footer.header"));
    }

    @Test
    void endFallsBackToWorldForMissingSections() {
        YamlConfiguration merged = new YamlConfiguration();
        deepMerge(global, merged);
        deepMerge(worldDefault, merged);
        deepMerge(end, merged);

        assertFalse(merged.getBoolean("scoreboard.enabled"));
        // Header still from world
        assertEquals(java.util.List.of("World Header"), merged.getStringList("header-footer.header"));
    }

    @Test
    void missingWorldUsesGlobalDefaults() {
        YamlConfiguration merged = new YamlConfiguration();
        deepMerge(global, merged);
        // No worldDefault, no specific

        assertEquals("Global Title", merged.getString("scoreboard.title"));
        assertEquals(java.util.List.of("Global Header"), merged.getStringList("header-footer.header"));
    }

    @Test
    void explicitDisableRemainsDisabled() {
        YamlConfiguration merged = new YamlConfiguration();
        deepMerge(global, merged);
        deepMerge(worldDefault, merged);
        deepMerge(end, merged);

        assertTrue(merged.isSet("scoreboard.enabled"));
        assertFalse(merged.getBoolean("scoreboard.enabled"));
    }

    @Test
    void missingKeyIsNotTreatedAsFalse() {
        YamlConfiguration partial = new YamlConfiguration();
        // scoreboard.enabled is NOT set
        partial.set("scoreboard.title", "Only Title");

        YamlConfiguration merged = new YamlConfiguration();
        deepMerge(global, merged);
        deepMerge(partial, merged);

        // Global enabled=true should remain because partial did not set the key
        assertTrue(merged.getBoolean("scoreboard.enabled"));
        assertEquals("Only Title", merged.getString("scoreboard.title"));
    }

    @Test
    void listOverrideReplacesEntireList() {
        YamlConfiguration partial = new YamlConfiguration();
        partial.set("scoreboard.lines", java.util.List.of("Only One Line"));

        YamlConfiguration merged = new YamlConfiguration();
        deepMerge(worldDefault, merged);
        deepMerge(partial, merged);

        assertEquals(1, merged.getStringList("scoreboard.lines").size());
        assertEquals("Only One Line", merged.getStringList("scoreboard.lines").get(0));
    }

    @Test
    void recursiveSectionMerge() {
        YamlConfiguration base = new YamlConfiguration();
        base.set("a.b.c", 1);
        base.set("a.b.d", 2);
        base.set("a.e", 3);

        YamlConfiguration overlay = new YamlConfiguration();
        overlay.set("a.b.c", 99);

        YamlConfiguration merged = new YamlConfiguration();
        deepMerge(base, merged);
        deepMerge(overlay, merged);

        assertEquals(99, merged.getInt("a.b.c"));
        assertEquals(2, merged.getInt("a.b.d"));
        assertEquals(3, merged.getInt("a.e"));
    }

    // Helper mirroring the production deepMerge logic
    private void deepMerge(org.bukkit.configuration.ConfigurationSection source,
                           org.bukkit.configuration.ConfigurationSection target) {
        if (source == null) return;
        for (String key : source.getKeys(false)) {
            Object srcVal = source.get(key);
            if (srcVal instanceof org.bukkit.configuration.ConfigurationSection) {
                org.bukkit.configuration.ConfigurationSection srcSec =
                        (org.bukkit.configuration.ConfigurationSection) srcVal;
                org.bukkit.configuration.ConfigurationSection tgtSec = target.getConfigurationSection(key);
                if (tgtSec == null) {
                    tgtSec = target.createSection(key);
                }
                deepMerge(srcSec, tgtSec);
            } else if (srcVal instanceof java.util.List) {
                target.set(key, new java.util.ArrayList<>((java.util.List<?>) srcVal));
            } else {
                target.set(key, srcVal);
            }
        }
    }
}
